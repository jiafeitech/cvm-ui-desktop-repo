# cvm-ui-desktop-distrologo

This package replaces the default Ubuntu logo with the Cvm UI Desktop logo.
