# Cvm UI Desktop OS Plymouth

This package contains bgrt, logo and text variants.

Based on the Vanilla OS Plymouth theme.
